print("\npost_install_cmd.py executed\n")
